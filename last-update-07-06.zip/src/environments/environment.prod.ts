export const environment = {
  apiEndpointBase: 'http://nirnayanwebcms.indiantechco.com/index.php/',
  production: true
};
