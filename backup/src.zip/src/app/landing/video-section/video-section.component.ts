import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-video-section',
  templateUrl: './video-section.component.html',
  styleUrls: ['./video-section.component.css']
})
export class VideoSectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
