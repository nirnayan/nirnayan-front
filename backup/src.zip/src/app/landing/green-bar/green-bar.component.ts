import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-green-bar',
  templateUrl: './green-bar.component.html',
  styleUrls: ['./green-bar.component.css']
})
export class GreenBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
