importScripts("https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js");
firebase.initializeApp({
 apiKey: "AIzaSyD_5WxJm0SWFsz0YeWZLiGaetmqjHfPpw4",
 authDomain: "b2c-front.firebaseapp.com",
 projectId: "b2c-front",
 storageBucket: "b2c-front.appspot.com",
 messagingSenderId: "955156638217",
 appId: "1:955156638217:web:10610b3e3daa6f0b2426d8",
 measurementId: "G-5M2XQYLVD8",
});
const messaging = firebase.messaging();