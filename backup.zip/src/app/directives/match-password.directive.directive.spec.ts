import { MatchPasswordDirectiveDirective } from './match-password.directive.directive';

describe('MatchPasswordDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new MatchPasswordDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
