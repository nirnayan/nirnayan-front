import { Component } from '@angular/core';

@Component({
  selector: 'app-about-footer',
  templateUrl: './about-footer.component.html',
  styleUrl: './about-footer.component.css'
})
export class AboutFooterComponent {

}
