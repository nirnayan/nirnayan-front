import { Ng2SearchPipe } from './ng2-search.pipe';

describe('Ng2SearchPipe', () => {
  it('create an instance', () => {
    const pipe = new Ng2SearchPipe();
    expect(pipe).toBeTruthy();
  });
});
